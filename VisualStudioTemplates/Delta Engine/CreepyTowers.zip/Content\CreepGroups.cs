namespace $safeprojectname$.Content
{
  public enum CreepGroups
  {
    Paper2,
		Paper3,
		Cloth2,
		Cloth3,
		Plastic2,
		Plastic3,
		GroupPpCl,
		GroupPpPl,
		GroupClPl,
  }
}