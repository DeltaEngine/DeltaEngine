namespace $safeprojectname$.Avatars
{
	public enum AvatarAttack
	{
		DragonAuraCannon,
		DragonBreathOfFire,
		PenguinBigFirework,
		PenguinCarpetBombing,
		PiggyBankCoinMinefield,
		PiggyBankPayDay
	}
}