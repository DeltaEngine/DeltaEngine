namespace $safeprojectname$.Enemy.Bosses
{
	public enum BossType
	{
		Cloak
	}
}
