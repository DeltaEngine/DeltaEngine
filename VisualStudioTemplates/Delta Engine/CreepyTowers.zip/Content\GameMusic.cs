namespace $safeprojectname$.Content
{
	public enum GameMusic
	{
		GameMusic
	}
}
