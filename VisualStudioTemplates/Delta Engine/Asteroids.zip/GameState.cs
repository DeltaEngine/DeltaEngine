namespace $safeprojectname$
{
	public enum GameState
	{
		MainMenu,
		Playing,
		GameOver,
	}
}
