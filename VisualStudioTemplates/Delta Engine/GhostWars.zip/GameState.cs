namespace $safeprojectname$
{
	public enum GameState
	{
		Menu,
		CountDown,
		Game,
		GameOver,
	}
}