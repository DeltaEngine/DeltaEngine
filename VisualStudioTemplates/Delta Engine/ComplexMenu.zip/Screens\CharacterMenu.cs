namespace $safeprojectname$.Screens
{
	/*TODO
	public partial class CharacterMenu : BaseGameScreen
	{
		public CharacterMenu()
		{
				this.InitializeControls();
				this.BackButton.Clicked += delegate
				{
					Close();
				};
				this.YesButton.Clicked += delegate
				{
					new NameMenu().Open();
				};
		}
	}
	 */
}
